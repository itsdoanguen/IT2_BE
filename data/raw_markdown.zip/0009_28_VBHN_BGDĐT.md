# 28/VBHN-BGDĐT

BỘ GIÁO DỤC VÀ ĐÀO TẠO
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc

Số: 28/VBHN-BGDĐT — Hà Nội, ngày 31 tháng 12 năm 2014

## VĂN BẢN HỢP NHẤT
### QUYẾT ĐỊNH
**Về học bổng khuyến khích học tập đối với học sinh, sinh viên trong các trường chuyên, trường năng khiếu, các cơ sở giáo dục đại học và trung cấp chuyên nghiệp thuộc hệ thống giáo dục quốc dân**

Quyết định số 44/2007/QĐ-BGDĐT ngày 15 tháng 8 năm 2007 của Bộ trưởng Bộ Giáo dục và Đào tạo về học bổng khuyến khích học tập đối với học sinh, sinh viên trong các trường chuyên, trường năng khiếu, các cơ sở giáo dục đại học và trung cấp chuyên nghiệp thuộc hệ thống giáo dục quốc dân, có hiệu lực kể từ ngày 14 tháng 9 năm 2007, được sửa đổi, bổ sung bởi:
- Thông tư số 31/2013/TT-BGDĐT ngày 01 tháng 8 năm 2013 của Bộ trưởng Bộ Giáo dục và Đào tạo sửa đổi, bổ sung khoản 3 Điều 2 Quyết định số 44/2007/QĐ-BGDĐT ngày 15 tháng 8 năm 2007 của Bộ trưởng Bộ Giáo dục và Đào tạo về học bổng khuyến khích học tập đối với học sinh, sinh viên trong các trường chuyên, trường năng khiếu, các cơ sở giáo dục đại học và trung cấp chuyên nghiệp thuộc hệ thống giáo dục quốc dân, có hiệu lực kể từ ngày 15 tháng 9 năm 2013.

Căn cứ Nghị định số 86/2002/NĐ-CP ngày 05 tháng 11 năm 2002 của Chính phủ quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của bộ, cơ quan ngang bộ;
Căn cứ Nghị định số 85/2003/NĐ-CP ngày 18/7/2003 của Chính phủ quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ Giáo dục và Đào tạo;
Căn cứ Nghị định số 75/2006/NĐ-CP ngày 02 tháng 8 năm 2006 của Chính phủ quy định chi tiết và hướng dẫn thi hành một số điều của Luật Giáo dục;
Xét đề nghị của Vụ trưởng Vụ Công tác học sinh, sinh viên,

Điều 1. Học bổng khuyến khích học tập ở trường chuyên và trường năng khiếu được quy định như sau:
1. Đối tượng và tiêu chuẩn xét cấp học bổng khuyến khích học tập:
a) Học sinh khối trung học phổ thông chuyên trong các trường đại học, học sinh trường chuyên đạt kết quả học tập xuất sắc được xét cấp học bổng là học sinh có hạnh kiểm tốt, học lực giỏi trong học kỳ xét cấp học bổng và đạt được một trong các tiêu chuẩn dưới đây:
- Điểm môn chuyên của học kỳ xét, cấp học bổng phải đạt từ 8,5 trở lên;
- Đoạt được một trong các giải từ khuyến khích trở lên trong các kỳ thi học sinh giỏi cấp quốc gia, khu vực quốc tế hoặc quốc tế của năm học đó.
b) Học sinh các trường năng khiếu nghệ thuật, thể dục thể thao đoạt huy chương trong các cuộc thi cấp quốc gia, khu vực quốc tế hoặc quốc tế của năm học đó, có học lực đạt từ trung bình và hạnh kiểm từ khá trở lên.
2. Mức học bổng khuyến khích học tập:
a) Đối với các trường chuyên, các trường năng khiếu nghệ thuật, thể dục thể thao: mức học bổng khuyến khích học tập cấp cho một học sinh một tháng tối thiểu bằng ba lần mức học phí hiện hành của trường trung học phổ thông chuyên tại địa phương;
b) Đối với khối trung học phổ thông chuyên trong các trường đại học: mức học bổng khuyến khích học tập cấp cho một học sinh do hiệu trưởng nhà trường quy định nhưng không thấp hơn mức trần học phí hiện hành mà học sinh đó phải đóng tại trường;
c) Đối với những trường không thu học phí: mức học bổng tối thiểu bằng ba lần mức trần học phí của trường trung học phổ thông tại địa phương.
3. Đối với các trường chuyên, trường năng khiếu quỹ học bổng khuyến khích học tập được bố trí trong dự toán chi ngân sách địa phương để cấp cho tối thiểu 30% số học sinh chuyên của trường. Đối với khối trung học phổ thông chuyên trong trường đại học, quỹ học bổng khuyến khích học tập được bố trí trong dự toán chi ngân sách nhà nước do Giám đốc hoặc Hiệu trưởng nhà trường quyết định.
4. Thủ tục xét, cấp học bổng khuyến khích học tập:
a) Đối với các trường chuyên và các trường năng khiếu, Hiệu trưởng nhà trường xác định số suất học bổng khuyến khích học tập cho từng lớp học và căn cứ vào quỹ học bổng của năm để cấp cho học sinh theo thứ tự ưu tiên: giải quốc tế, khu vực quốc tế, quốc gia, điểm môn chuyên (đối với các trường chuyên) hoặc kết quả học tập (đối với các trường năng khiếu);
b) Đối với khối trung học phổ thông chuyên trong trường đại học: Giám đốc hoặc Hiệu trưởng nhà trường xác định số suất học bổng khuyến khích học tập và mức học bổng cho từng khối, lớp học căn cứ vào quỹ học bổng của năm để xét, cấp cho học sinh theo thứ tự ưu tiên: giải quốc tế, khu vực quốc tế, quốc gia, điểm môn chuyên.
Học bổng khuyến khích học tập được cấp theo từng học kỳ và cấp 9 tháng theo biên chế năm học.
Ngoài học bổng khuyến khích học tập theo quy định tại Quyết định này, Chủ tịch Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương có thể có các chế độ, chính sách khác đối với học sinh các trường chuyên, trường năng khiếu thuộc địa phương hoặc do địa phương quản lý.

Điều 2. Học bổng khuyến khích học tập ở cơ sở giáo dục đại học và trung cấp chuyên nghiệp được quy định như sau:
1. Đối tượng được xét, cấp học bổng khuyến khích học tập là học sinh, sinh viên đang học trong các đại học, học viện, trường đại học, trường cao đẳng, trường trung cấp chuyên nghiệp hệ giáo dục chính quy công lập và các trường đại học, trường cao đẳng, trường trung cấp chuyên nghiệp hệ giáo dục chính quy ngoài công lập (sau đây gọi chung là trường).
Học sinh, sinh viên thuộc diện hưởng học bổng chính sách, học sinh, sinh viên thuộc diện trợ cấp xã hội và học sinh, sinh viên diện chính sách ưu đãi theo quy định hiện hành nếu đạt kết quả học tập, rèn luyện vào diện được xét, cấp học bổng tại Quyết định này thì được xét, cấp học bổng khuyến khích học tập như những học sinh, sinh viên khác.
2. Tiêu chuẩn và mức xét, cấp học bổng khuyến khích học tập:
Học sinh, sinh viên có kết quả học tập, rèn luyện từ loại khá trở lên, không bị kỷ luật từ mức khiển trách trở lên trong học kỳ xét học bổng thì được xét, cấp học bổng khuyến khích học tập trong phạm vi quỹ học bổng khuyến khích học tập của trường theo các mức sau:
a) Mức học bổng loại khá: Có điểm trung bình chung học tập đạt loại khá trở lên và điểm rèn luyện đạt loại khá trở lên. Mức học bổng tối thiểu bằng hoặc cao hơn mức trần học phí hiện hành của ngành nghề mà học sinh, sinh viên đó phải đóng tại trường do Hiệu trưởng hoặc Giám đốc quy định (sau đây gọi chung là Hiệu trưởng). Riêng các trường ngoài công lập mức học bổng tối thiểu do Hiệu trưởng nhà trường quy định. Đối với những ngành nghề đào tạo không thu học phí thì áp dụng theo mức trần học phí được Nhà nước cấp bù cho nhóm ngành đào tạo của trường;
b) Mức học bổng loại giỏi: Có điểm trung bình chung học tập đạt loại giỏi trở lên và điểm rèn luyện đạt loại tốt trở lên. Mức học bổng cao hơn loại khá và do Hiệu trưởng quy định;
c) Mức học bổng loại xuất sắc: Có điểm trung bình chung học tập đạt loại xuất sắc và điểm rèn luyện đạt loại xuất sắc. Mức học bổng cao hơn loại giỏi và do Hiệu trưởng quy định.
Điểm trung bình chung học tập được xác định theo quy định hiện hành của Quy chế đào tạo đại học và cao đẳng hệ chính quy, Quy chế đào tạo trung cấp chuyên nghiệp hệ chính quy do Bộ Giáo dục và Đào tạo ban hành (chỉ được lấy điểm thi, kiểm tra hết môn học lần thứ nhất, trong đó không có điểm thi dưới 5,0 hoặc kiểm tra hết môn học không đạt). Kết quả rèn luyện được xác định theo quy định của Quy chế đánh giá kết quả rèn luyện hiện hành do Bộ Giáo dục và Đào tạo ban hành.
d) Học bổng khuyến khích học tập được cấp theo từng học kỳ và cấp 10 tháng trong năm học.
3. Quỹ học bổng khuyến khích học tập được bố trí tối thiểu bằng 8% nguồn thu học phí hệ giáo dục chính quy đối với các trường công lập và tối thiểu bằng 2% nguồn thu học phí hệ giáo dục chính quy đối với các trường ngoài công lập. Đối với các trường sư phạm và các ngành nghề đào tạo không thu học phí thì quỹ học bổng được trích tối thiểu bằng 8% nguồn ngân sách nhà nước cấp bù học phí. *(Khoản này được sửa đổi theo Điều 1 Thông tư số 31/2013/TT-BGDĐT, có hiệu lực từ 15/9/2013).*
4. Thủ tục xét, cấp học bổng khuyến khích học tập:
a) Hiệu trưởng nhà trường căn cứ vào quỹ học bổng khuyến khích học tập xác định số lượng suất học bổng khuyến khích học tập cho từng khóa học, ngành học. Trong trường hợp nếu số lượng học sinh, sinh viên thuộc diện được xét cấp học bổng nhiều hơn số suất học bổng thì thủ tục xét, cấp học bổng do Hiệu trưởng quy định;
b) Hiệu trưởng căn cứ vào kết quả học tập và rèn luyện của học sinh, sinh viên tiến hành xét, cấp học bổng theo thứ tự từ loại xuất sắc trở xuống đến hết số suất học bổng đã được xác định.
Học sinh, sinh viên đào tạo theo học chế tín chỉ được xét, cấp học bổng khuyến khích học tập theo số lượng tín chỉ (15 tín chỉ được tính tương đương với một học kỳ). Thủ tục và tiêu chuẩn xét, cấp học bổng khuyến khích học tập theo học chế tín chỉ thực hiện như thủ tục và tiêu chuẩn xét, cấp học bổng khuyến khích học tập theo học kỳ.

Điều 3. Quyết định này có hiệu lực thi hành sau 15 ngày, kể từ ngày đăng Công báo. Các quy định trước đây trái với Quyết định này đều bị bãi bỏ.

Điều 4. Chánh Văn phòng, Vụ trưởng Vụ Kế hoạch - Tài chính, Vụ trưởng Vụ Công tác học sinh, sinh viên, Thủ trưởng các đơn vị thuộc cơ quan Bộ Giáo dục và Đào tạo, Chủ tịch Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương, Giám đốc sở giáo dục và đào tạo, Giám đốc các đại học, học viện, Hiệu trưởng các trường đại học, cao đẳng, trung cấp chuyên nghiệp, Hiệu trưởng các trường chuyên, trường năng khiếu nghệ thuật, thể dục thể thao chịu trách nhiệm thi hành Quyết định này./.

XÁC THỰC VĂN BẢN HỢP NHẤT
Số: 28/VBHN-BGDĐT — Hà Nội, ngày 31 tháng 12 năm 2014
KT. BỘ TRƯỞNG
THỨ TRƯỞNG
Phạm Mạnh Hùng
