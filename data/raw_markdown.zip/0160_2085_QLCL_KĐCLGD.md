# 2085/QLCL-KĐCLGD

BO GIAO DUC VA DAO TAO CONG HOA XA HOI CHU NGHiA VIET NAM CUC QUANLY CHAT LUONG Doc lap - Tu do - Hanh phic S6: 2085/QLCL-KDCLGD Ha Noi, ngay 31 thang 12 nam 2020 V/v huong dan tur danh gia va danh gia ngoai CTDT Kinh guri:
- Cac co so giao duc dai hoc;
- Cac truong cao dang co dao tao giao vien;
- Cac to chirc kiem dinh chat luong giao duc.
Dé trién khai cong tac tu danh gia va danh gia ngoai chuong trinh dao tao (CTDT) cua co so giao duc dai hoc, truong cao dang co dao tao giao vien theo cac quy dinh hien hanh', Cuc Quan ly chat luong - Bo Giao duc va Dao tao (GDDT) hurong dan trien khai cong tac tur danh gia va danh gia ngoai CTDT nhu sau:
Phan I TU DANH GIA CHUONG TRINH DAO TAO I. VAI TRO VA YEU CAU TU DANH GIA
1. Vai tro cua viec tur danh gia chuo'ng trinh dao tao
a) La khau dau tien quan trong trong viec bao dam chat luong CTDT cua co so giao duc. Giup co so giao duc thuc hien CTDT tur ra soat, xem xet, danh gia thurc trang cua CTDT; xac dinh dung diém manh, diém ton tai cua CTDT tu do xay dung ke hoach cai tién chat luong (ké hoach hanh dong) phu hop, kha thi va trien khai cac ké hoach hanh dong nham cai tién va nang cao chat luong CTDT;
b) La dieu kien can thiét dé co so giao duc dang ky danh gia ngoai va de nghi cong nhan dat tieu chuan chat luong CTDT voi mot to churc KDCLGD;
Quy dinh ve quy trinh va chu ky kiém dinh chat lurong CTDT cua cac trurong dai hoc, cao dang va trung cap chuyen nghiep ban hanh kem theo Thong tur so 38/2013/TT-BGDDT ngay 29/11/2013 cua Bo trurong Bo GDDT. Cac tieu chuan danh gia chat lurong CTDT hien hanh duoc ban hanh theo cac thongtur sau:
- Thong tur so 23/2011/TT-BGDDT ngay 16/6/2011 cua Bo trurong Bo GDDT ban hanh Quy dinh ve tieu chuan danh gia chat lurong churong trinh giao duc su pham ky thuat cong nghiep trinh do dai hoc;
- Thong tur so 49/2012/TT-BGDDT ngay 12/12/2012 cua Bo trurong Bo GDDT ban hanh Quy dinh ve tieu chuan danh gia chat lurong chuong trinh dao tao giao vien trung hoc pho thong trinh do dai hoc;
- Thong tur so 33/2014/TT-BGDDT ngay 02/10/2014 cua Bo trurong Bo GDDT ban hanh Quy dinh ve tieu chuan danh gia chat lurong churong trinh dao tao dieu duong trinh do dai hoc, cao dang;
- Thong tur so 04/2016/TT-BGDDT ngay 14/3/2016 cua Bo trurong Bo GDDT ban hanh Quy dinh ve tieu chuan danh gia chat luong churong trinh dao tao cac trinh do cia giao duc dai hoc;
- Thong tur so 02/2020/TT-BGDDT ngay 05/02/2020 cia Bo trurong Bo GDDT quy dinh ve tieu chuan danh gia chat luong churong trinh dao tao giao vien trinh do cao dang su pham va trung cap su pham;
- Thong tur so 39/2020/TT-BGDDT ngay 09/10/2020 cua Bo trurong Bo GDDT quy dinh ve tieu chuan danh gia chat lurong churong trinh dao tao tur xa trinh do dai hoc.

trong toan bo hoat dong dao tao, nghien ciru khoa hoc, phuc vu cong dong theo churc nang, nhiem vu duoc giao, phu hop voi su mang va muc tieu da dugc xac dinh.
2. Cac yeu cau cua viec tur danh gia churong trinh dao tao
a) Trong qua trinh tu danh gia (TDG) CTDT, can cur vao tung tieu chuan va tieu chi, co so giao duc phai tap trung thurc hien nhung viec sau:
- Mo ta lam ro thuc trang cua CTDT;
- Phan tich, giai thich, so sanh, doi chieu va dua ra nhirng nhan dinh; chi ra nhirng diem manh, diem ton tai va nhing bien phap khac phuc;
- Lap ke hoach hanh dong de cai tien, nang cao chat luong CTDT.
b) Tu danh gia CTDT la mot qua trinh lien tuc, doi hoi nhieu cong surc, thoi gian va phai co sur tham gia cua nhieu ca nhan trong toan don vi thuc hien CTDT cung nhu su phoi hop cua cac ca nhan, don vi khac trong co so giao duc.
c) Hoat dong TDG CTDT doi hoi tinh khach quan, trung thurc, cong khai va minh bach. Cac giai thich, nhan dinh, ket luan dua ra trong qua trinh TDG phai dua tren cac minh churng cu the, ro rang, bao dam do tin cay. Viec TDG phai bao dam danh gia day du cac tieu chi trong bo tieu chuan danh gia chat luong CTDT do Bo GDDT ban hanh.
II. QUY TRINH TU DANH GIA Tu danh gia CTDT dugc quy dinh tur

Dieu 6 den

Dieu 13 theo Thong tur so 38/2013/TT-BGDDT ngay 29/11/2013 cua Bo trurong Bo GDDT ban hanh Quy dinh vé quy trinh va chu ky kiem dinh chat luong chuong trinh dao tao cua cac trurong dai hoc, cao dang va trung cap chuyen nghiep (sau day goi tat Thong tu so 38/2013/TT-BGDDT). Cu the nhu sau:
1. Hoi dong tur danh gia Sé luong, thanh phan va nguyen tac hoat dong cua Hoi dong TDG CTDT thurc hien theo

Dieu 7 Thong tur so 38/2013/TT-BGDDT. Mau Quyet dinh thanh lap Hoi dong TDG tham khao Phu luc 1.
Churc nang, nhiem vu cua Hoi dong TDG thurc hien theo

Dieu 8 Thong tur so 38/2013/TT-BGDDT. Cac don vi lien quan trong co so giao duc co trach nhiem phoi hop va ho tro cac nhom cong tac cua Hoi dong de trien khai TDG.
2. Lap ke hoach tur danh gia Hoi dong TDG xay dung ke hoach TDG nham sir dung co hieu qua thoi gian va cac nguon lurc cua co so giao duc de bao dam dat duroc muc dich cua dot TDG.
Ké hoach TDG CTDT phai the hien dugc cac noi dung theo khoan 2

Dieu 9 Thong tur so 38/2013/TT-BGDDT. Mau Ké hoach TDG CTDT tham khao Phu luc 2.
3. Thu thap, phan tich va xir ly thong tin va minh chirng
a) Thong tin va minh ching

Thong tin, minh chung durgc hiéu la nhung tur lieu, van ban, ho so, so sach, bang, dia, hien vat,... da va dang co cua nha truong phu hop voi noi ham (yeu cau) cua tieu chi danh gia chat luong CTDT. Thong tin, minh chung duoc si dung de chung minh cho cac nhan dinh, ket luan trong muc “Mo ta hien trang" tung tieu chi cua bao cao TDG, trong do co nhing minh churng va nhirng thong tin gan voi cac tieu chi de xac dinh murc do dat duoc cua tieu chi.
Thong tin, minh chung co the dugc thu thap tu ho so luu tru cua nha truong, cac co quan co lien quan; tur két qua khao sat, dieu tra, phong van, quan sat cac hoat dong nha truong. Minh chung phai co nguon goc ro rang va bao dam tinh chinh xac.
Thong tin, minh chung thu dugc khong chi sir dung cho muc dich danh gia cac mirc dat cua turng tiéu chi, ma con nham mo ta hien trang cac hoat dong cua CTDT de nguoi doc hieu hon, qua do lam tang tinh thuyet phuc cua bao cao TDG.
b) Xac dinh noi ham, phan tich tieu chi tim minh chitng Dé xac dinh dung, du noi ham cua turng tieu chi can luu y: (i) Tieu chi thuong co nhing tur, cum tir quan trong co y nghia nhu la “tur khoa"; (i) Noi ham cua moi tieu chi co mot hoac mot so yeu cau; (iii) Can xac dinh noi ham cua tirng tieu chi doi chieu voi cac quy dinh lien quan va voi thurc tien cua co so giao duc trong chu ky KDCLGD; (iv) Doi chiéu “Muc tieu cu the" cua nha trurong lien quan noi ham tieu chi.
Tren co so da xac dinh dung, du noi ham tieu chi, nhom cong tac hoac ca nhan se phan tich tieu chi de tim nhiung thong tin, minh chung can thu thap, noi thu thap va ghi vao Phieu phan tich tieu chi, thu thap thong tin va minh chung (tham khao Phu luc 3).
Dé danh gia thuc trang tung yeu cau cua tieu chi, nha truong co the tur dat ra va tra loi (urng voi yeu cau) cac cau hoi nhu: Nha trurong co hay khong lap ké hoach thuc hien yeu cau? Nha trurong da thuc hien, da dat dugc yeu cau chua?
Yeu cau da dat duoc cia nha trurong so voi yeu cau theo quy dinh chung nhu the nao? So voi cac trurong khac cung co dieu kien tuong dong (kinh te - xa hoi, van hoa,...) nhu thé nao? Nha truong da thurc hien “vuot tren"' yeu cau nhu the nao?
Nha truong ra soat, kiém tra viec thuc hien yeu cau nhu the nao, da co nhtng cai tien chat lugng gi? Nhung minh chung de khang dinh nha trurong co ke hoach, thurc hien yeu cau, ra soat, kiem tra viec thuc hien yeu cau, ...
Tra loi nhung cau hoi tren, nha trurong co the da phan tich duoc tieu chi, dinh huong dugc viec thu thap thong tin, minh chung va chuan bi cho cac buoc tiep theo cua quy trinh TDG.
c) Thu thap thong tin, minh chirng Can cur vao cac Phieu phan tich tieu chi, thu thap thong tin va minh churng, nhom cong tac hoac ca nhan duroc phan cong tien hanh thu thap thong tin, minh churng, sap xep minh chung theo thur tu noi ham tieu chi.

Trong trurong hop khong the tim duoc thong tin, minh churng cho mot tieu chi nao do (hoa hoan, thien tai hoac nhung nam truoc khong luu ho so, ...) , Hoi dong TDG phai lam ro nguyen nhan va ghi vao Phiéu danh gia tieu chi (tham khao Phu luc 4a va Phu luc 4b).
Khi thu thap thong tin va minh churng, Hoi dong TDG can kiem tra do tin cay, tinh xac thurc, murc do phu hop lien quan den tieu chi. Hoi dong TDG phai luon dat cau hoi ve cac thong tin thu durgc: Néu nguroi khac di thu thap thong tin do thi co thu dugc ket qua turong tu nhu the khong? Lieu nhing thong tin do co mang lai nhirng hiéu biet moi, ro rang va chinh xac vé thuc trang cac hoat dong cia CTDT hay khong?
Trong qua trinh thu thap thong tin va minh chung, phai chi ro nguon goc cua chung. Luu trur cac thong tin, minh chung, ké ca cac tur lieu lien quan den nguon goc cua cac thong tin va minh chung thu duroc, co bien phap bao ve cac thong tin va minh churng do.
Luu y: Trong qua trinh thu thap thong tin, minh churng, nha truong nen co cac co so du lieu sau day de co day di thong tin va minh churng phuc vu cho viec viét bao cao TDG CTDT: (i) Bao cao hang nam ve viec nguoi hoc danh gia chat luong dao tao cia CTDT truroc khi tot nghiep; bao gom quy trinh, cong cu, du lieu va két qua danh gia; (ii) Bao cao hang nam ket qua khao sat tinh hinh viec lam cia nguroi hoc sau khi tot nghiep; bao gom quy trinh, cong cu, du lieu va ket qua danh gia; (3) Bao cao khao sat hang nam vé mrc do dap irng cua thu vien, phong thi nghiem, he thong cong nghe thong tin, co so vat chat va cac dich vu khac so voi yeu cau sir dung cia giang vien, nhan vien va nguoi hoc; bao gom quy trinh, cong cu, du lieu va két qua danh gia. Co so du lieu kiém dinh chat luong CTDT tham khao Phu luc 7.
d) Xi ly, phan tich cdc thong tin va minh chung thu duoc Hoi dong TDG thao luan cac minh chung cho tung tieu chi da thu thap dugc cua nhom cong tac hoac ca nhan. Khi cac minh churng durgc sur dung, Hoi dong TDG lap Bang danh muc minh chung (tham khao Phu luc 9).
Trong thurc té, mot so thong tin co thé su dung ngay de lam minh churng nhung mot so thong tin khac phai qua xir ly, phan tich, tong hop moi co the sur dung de lam minh chung cho cac nhan dinh, ket luan dua ra trong muc “Mo ta hien trang" cua bao cao TDG. Vi du, hau hét thong tin thu duroc sau cac keét qua khao sat dieu tra, phong van va quan sat phai xir ly thanh dang so lieu tong hop moi co thé dua vao lam minh chung trong muc “Mo ta hien trang"' cia bao cao TDG. Thong tin thu thap duoc, nen xi ly de tranh lam anh hurong den cac don vi hoac ca nhan cung cap thong tin.
Cac minh chung phu hop voi noi ham tieu chi se duoc si dung trong muc “Mo ta hien trang"' cua Phieu danh gia tieu chi. Cac minh chung nay, truroc khi durgc sur dung can thiet phai ma hoa voi muc dich gon, tien tra curu. Viec ma hoa minh churng tham khao Phu luc 8.

Trong truong hop nha truong khong de rieng cac minh chung trong cac hop (cap) ma van de trong ho so luru trtr cia nha truong, thi phai ghi ro vi tri cu the (durong dan) cua minh churng dat trong ho so luru trur cua nha trurong vao Bang danh muc minh chung (xem Phu luc 9).
a) Si dung minh ching M6i minh chung chi dugc ma hoa mot lan. Minh chung durgc dung cho nhieu tieu chi trong mot tieu chuan hoac nhieu tieu chuan thi mang ma minh chung cia tieu chi, tieu chuan durgc sur dung lan thur nhat.
Phiéu danh gia tieu chi (tham khao Phu luc 4a va 4b), gom cac noi dung:
Mo ta hien trang, diem manh, diem ton tai, ke hoach hanh dong va TDG. Phiéu danh gia tieu chi do nhom cong tac hoac ca nhan viét va dugc lay y kien cua Hoi dong TDG. Moi tieu chi dugc danh gia theo mot Phiéu danh gia tieu chi.
Minh chung thu duoc lien quan den moi tieu chi duoc trinh bay trong muc ta va phan tich cac hoat dong cua CTDT lien quan dén tieu chi; (ii) So sanh voi hay voi cac quy dinh cua Nha nuoc de thay dugc hien trang cua CTDT; (ii) Dua ra nhung nhan dinh ve diem manh va nhing van de can phat huy, chi ra nhurng diem ton tai, giai thich nguyen nhan; (iv) Xac dinh nhung van de can cai tien chat luong va de ra nhing bien phap de cai tien nhung van de do; (v) Xac dinh muc do dat duoc cua tieu chi. Voi moi tieu chi, néu co day du minh churng dap irng cac yeu cau cua tieu chi thi xac nhan tieu chi do dat yeu cau theo murc danh gia turong urng.
Moi nhan dinh, ket luan trong muc “Mo ta hien trang"' cua Phiéu danh gia tieu chi (sau do duroc sur dung trong bao cao TDG) phai co minh churng kem theo.
duroc nhung diem manh, diem ton tai cua CTDT va xay durng ke hoach hanh dong phu hop, kha thi. Phieu danh gia tieu chi la tai lieu ghi nhan ket qua lam viec cua tirng tieu chi, tieu chuan. Vi vay, moi nhom cong tac phai bao dam do chinh xac, trung thurc va su nhat quan cua cac Phiéu danh gia tieu chi trong moi tieu chuan.
Viec danh gia cac murc dat dugc cua tieu chi durgc viét trong muc TDG cua Phieu danh gia tieu chi (Phu luc 4a va 4b).
Nham nang cao chat lurong cac noi dung trong Phieu danh gia tieu chi, quy trinh viét nen durgc thuc hien trinh tu nhur sau: (i) Nhom cong tac hoac ca nhan nghien ciru, phan tich noi ham cua tieu chi va cac minh chung duoc sur dung de viét cac noi dung cua Phiéu danh gia tieu chi; (ii) Nhom cong tac thao luan cac noi dung cua Phieu danh gia tieu chi dé chinh sura, bo sung; (ii) Hoi dong TDG thao luan cac noi dung cua turng Phieu danh gia tieu chi. Trong do, dac biet chu y dén ké hoach hanh dong tung tieu chi de xac dinh ro cac bien phap, giai phap, dieu kien (nhan lurc, tai chinh), thoi gian thurc hien, thoi gian hoan thanh va phai co tinh kha

thi; (iv) Tren co so y kién cua Hoi dong TDG, nhom cong tac hoac ca nhan hoan thien Phieu danh gia tieu chi va guri thur ky Hoi dong TDG.
Luu y: (i) Trong trurong hop khong co minh chung de chirng minh mirc do dat durgc cua tieu chi do thi ghi “Khong co minh churng"; (i) Trong qua trinh xur ly, phan tich, neu mot so thong tin va minh chung thu duroc khong phu hop voi cac két qua nghien ciru, danh gia o trong va ngoai co so giao duc ve CTDT da dugc cong bo truoc do thi Hoi dong TDG co trach nhiem kiem tra lai cac thong tin va minh churng do, giai thich ly do khong phu hop.
e) Luu trit va bao qudn hoa. Minh chung het gia tri duroc thay the bang minh churng dang con hieu lurc va phu hop. Minh churng thay the duoc ghi ky hieu cua minh ching bi thay the va ghi ro ngay, thang, nam thay the. Nhing minh chung phuc vu cong tac quan ly cac hoat dong cua CTDT thi luru trit, bao quan tai ho so luru tru cua nha truong, nhung phai ghi ro vi tri cu the (durong dan) cua minh chung trong Bang danh muc minh churng de tien loi trong viec tra curu, tim kiem.
Doi voi nhing minh chung nhu: cac hien vat; he thong ho so, so sach;
cac van ban, tai lieu, tur lieu co so luong lon va so trang nhieu,.. nha truong co the lap cac bieu, bang tong hop, thong ke cac du lieu, so lieu dé thuan tien cho viec sir dung. Khuyen khich su dung cong nghe thong tin de so hoa cac minh churng, thuan tien cho viec luu tru va doi chiéu khi can thiét.
Minh chung dugc luru trir, bao quan theo quy dinh cua Luat luu trtr va cac quy dinh hien hanh.
4. Viét bao cao tur danh gia
a) Bao cao TDG CTDT thuc hien theo Diéu 1l cua Thong tur si 38/2013/TT-BGDDT. Két qua TDG durgc trinh bay duoi dang mot ban bao cao co hinh thurc va cau truc theo Huong dan nay (tham khao Phu luc 5, 6a, 6b, 7, 8 va 9). Bao cao TDG la mot ban ghi nho quan trong nham cam két thuc hien cac hoat dong cai tién chat luong cia CTDT.
b) Sir dung cac Phiéu danh gia tieu chi (Phu luc 4a va Phu luc 4b) dé viét két qua TDG theo cac tieu chi.
c) Két qua danh gia tiung tieu chi dugc tong hop vao Bang tong hop két qua TDG CTDT (tham khao Phu luc 6a va Phu luc 6b).
d) Tuy theo ké hoach phat trién va chien lugc uu tien cua co so giao duc, cua don vi thuc hien CTDT ma xac dinh trong tam cai tien chat lurong cho tung giai doan. Ve tong the, don vi phai co ke hoach khac phuc tat ca nhung diem ton tai, thieu sot cua CTDT.
d) Trong mot bao cao TDG, do dai ngan cua cac phan viét ve tung tieu chuan, tieu chi khong nhat thiet phai giong nhau, nhung cing khong nen qua chenh lech.

e) Du thao bao cao TDG cuoi cung phai dugc chuyén cho nhung nguoi cung cap thong tin va minh churng dé xac minh lai cac thong tin, minh chung da dugc sir dung va murc do chinh xac cua cac nhan dinh rut ra tur do. Cac nhom cong tac chiu trach nhiem ra soat lai phan bao cao co lien quan dén cac tieu chi, tieu chuan dugc giao. Cac thanh vien Hoi dong TDG ky xac nhan vao ban bao cao TDG sau khi da doc va nhat tri voi noi dung bao cao TDG.
g) Bao cao TDG dat yeu cau khi: trinh bay theo thé thurc, ky thuat trinh bay va cau truc cua Hurong dan nay; khong co loi chinh ta, loi ngu phap; khong mau thuan gitra cac noi dung trong mot tieu chi va giura cac tieu chi; cac minh chung phai du, ro rang va thuyet phuc; co minh chung du co so de khang dinh murc dat duoc cua chi bao, tieu chi; danh gia dung thurc trang CTDT cua co so giao duc.
Thé thurc va cau truc cua bao cao TDG (xem Phu luc 19).
5. Luu trir va sir dung bao cao tur danh gia Luu trur va sur dung bao cao TDG theo Diéu 12 cia Thong tu si 38/2013/TT-BGDDT.
6. Trien khai cac hoat dong sau khi hoan thanh bao cao tur danh gia Trien khai cac hoat dong sau khi hoan thanh bao cao TDG theo

Dieu 13 cua Thong tur so 38/2013/TT-BGDDT. Nha truong co CTDT duroc danh gia co trach nhiem to churc thuc hien theo Diéu 29 Thong tur so 38/2013/TT-BGDDT. Trong do, doi voi viec bao cao co quan quan ly trurc tiep va Bo GDDT:
a) Co so giao duc co trach nhiem guri du lieu ve TDG va viec cai tién chat luong sau danh gia vao he thong quan ly cua Bo GDDT theo huong dan cu the (trong thoi gian toi).
b) Sau khi hoan thanh bao cao TDG, co so giao duc guri bao cao TDG CTDT cho co quan quan ly trurc tiep (neu co) kem theo cong van de nghi co quan quan ly trurc tiep quan tam, ho tro trong qua trinh thurc hien cai tien, nang cao chat luong CTDT theo cac ke hoach hanh dong da neu trong bao cao TDG.
tut) ve Cuc Quan ly chat luong, Bo GDDT qua e-mail: phongkdclgd@moet.gov.vn.
Cu the:
- Cong van thong bao ve viec da hoan thanh bao cao TDG (tep van ban word va pdf), trong do neu ro: Giai doan danh gia; Thoi gian tién hanh TDG;
Viec TDG da durgc thuc hien theo dung quy trinh va bao cao TDG durgc viet theo dung hurong dan cua Bo GDDT; Két qua danh gia; Du kien thoi gian danh gia ngoai.
- Bao cao TDG (tep van ban word va pdf).
voi co' so gido duc dai hoc X, hoan thanh bao cdo TDG CTDT Y nam 2020):

- Ten tep cong van (khong dau): tentruong_ctdt_cv_namhoanthanh (vi du:
dhX ctdt_cv_2020);
- Ten tep bao cao TDG (khong dau): tentruong_bctdgct..._namhoanthanh (vi du: dhX_bctdgctY_2020).
d) Trong thoi gian 10 ngay lam viec ke tur ngay co so giao duc guri e-mail., Cuc Quan ly chat luong co trach nhiem guri e-mail y kien phan hoi cho co so giao duc ve cau truc, trinh bay,.. cua bao cao TDG CTDT. Neu sau 15 ngay lam viec khong co phan hoi cua Cuc Quan ly chat lurong thi bao cao TDG do durgc tién hanh lam buoc tiep theo. Sau khi nhan dugc phan hoi cua Cuc Quan ly chat luong, don vi thuc hien CTDT ra soat va sura lai bao cao TDG theo yeu cau cua Cuc Quan ly chat lurong hoac giai trinh (néu gitr nguyén y kien) va guri lai cho Cuc Quan ly chat lurong. Néu bao cao TDG dap urng cac quy dinh, Cuc Quan ly chat luong cap nhat ten co so giao duc, ten CTDT vao danh sach cac co so giao duc da hoan thanh bao cao TDG CTDT va dang tren Cong thong tin dien tur cia Bo GDDT (www.moet.gov.vn).
Doi voi CTDT cua cac co so giao duc thuoc Bo Cong an va Bo Quoc phong, sau khi hoan thanh bao cao TDG CTDT, guri bao cao TDG cho co quan quan ly trurc tiép de to churc tham dinh truoc khi danh gia ngoai. Co quan bao cac CTDT da hoan thanh bao cao TDG vé Cuc Quan ly chat lurong de theo doi chung.
e) Bao cao TDG la can cu dé thuc hien cac ké hoach cai tién chat luong CTDT hang nam. Truong hop co so giao duc dang ky danh gia ngoai dé duroc cong nhan CTDT dat tieu chuan chat luong giao duc, ngay sau khi ky hop dong danh gia ngoai voi to churc KDCLGD, co so giao duc guri vé Cuc Quan ly chat luong file van ban thong bao viec da ky hop dong danh gia ngoai, kem theo file Word va file pdf Bao cao TDG (da durgc to chirc KDCLGD tham dinh, chuan bi cho danh gia ngoai). Co so giao duc chi dang ky danh gia ngoai cac CTDT da duoc cap nhat vao danh sach hoan thanh bao cao TDG CTDT dang tren Cong thong tin dien tur cua Bo GDDT.
III.HOSOLUUTRU
1. Ho so luru trir gom
a) Quyet dinh thanh lap hoi dong TDG;
b) Ké hoach TDG;
c) Cac Phiéu danh gia tieu chi;
d) Bao cao TDG;
d) Cac thong tin, minh churng (co the luu triur rieng hoac luru tru, bao quan tai ho so luu trtr dang sir dung cua nha trurong, nhung phai bao dam nguyen tac thuan tien tra ciru va sir dung);

e) Cac van ban lien quan (néu co).
2. Thoi han bao quan, luru trir va sir dung ho so nn en eno uip Knb oa sunp ns ea n nny'uenb onq ey ol va cac quy dinh hien hanh.
Phan II DANH GIA NGOAI CHUONG TRiNH DAO TAO I. DOAN DANH GIA NGOAI
1. Thanh lap doan danh gia ngoai Giam doc to churc KDCLGD ra quyét dinh thanh lap doan danh gia ngoai (DGN) voi so lurong va tieu chuan cua cac thanh vien dap ung quy dinh tai

Dieu 16 cua Thong tu so 38/2013/TT-BGDDT.
To chuc KDCLGD can lua chon co cau thanh vien doan DGN hop ly, trong do luu y den kinh nghiem DGN cua turng thanh vien; khuyen khich viec bo tri them quan sat vien (nhung nguoi da hoan thanh CTDT kiem dinh vien chat lurong giao duc hoac da co the kiem dinh vien kiem dinh chat luong giao duc) de tirng buroc nang chat lurong doi ngi kiem dinh vien chat lurong giao duc cua toan he thong; khong cir nguoi da tirng huong dan, tu van cho co so giao duc trong qua trinh trien khai va hoan thien bao cao TDG tham gia doan DGN.
To churc KDCLGD co thé bo tri giam sat vien giam sat cong tac DGN.
Giam sat vien co trach nhiem kip thoi phan anh voi to churc KDCLGD ve hoat dong cua doan DGN de bao dam thuc hien dung cac quy dinh cua Bo GDDT va cua to churc KDCLGD.
Cac thanh vien doan DGN, quan sat vien va giam sat vien can tuan thu KDCLGD, khong vi muc dich lgi nhuan; dong thoi, co van ban cam ket hoac thoa thuan voi to churc KDCLGD ve dao durc nghe nghiep, co trach nhiem gitr bi mat thong tin lien quan den hoat dong DGN theo quy dinh tai diem c, khoan 5
Dieu 17 cua Thong tur so 38/2013/TT-BGDDT; ton trong cac doi tuong phong van, cac thanh vien cua co so giao duc va cac thanh vien khac trong doan.
Quan sat vien va giam sat vien co thé dugc tham gia cac khau cua qua trinh danh gia, dugc dur cac phien lam viec cua doan DGN voi co so giao duc, durgc moi tham gia y kien cho doan DGN nhung khong durgc dura ra cac y kien ve murc dat dugc cua cac tieu chi. Quan sat vien cing co the durgc trurong doan
2. Vai tro va trach nhiem cua cac thanh vien doan danh gia ngoai
a) Truong doan Truong doan chiu trach nhiem dieu hanh cac hoat dong cua doan; chiu trach nhiem chinh trong viec lap ké hoach cong tac, phan cong nhiem vu cho cac thanh vien cua doan; bao dam thuc hien tot ke hoach khao sat tai co so giao duc

va diéu hanh cac hoat dong cua doan; thay mat doan thong bao va thao luan voi co so giao duc ve ket qua khao sat, nhung nhan dinh va khuyen nghi cua doan doi voi CTDT cua co so giao duc; chiu trach nhiem chinh trong viec xay dung bao cao két qua nghien curu ho so TDG, bao cao két qua khao sat tai co so giao duc va bao cao DGN cua doan; tap hop toan bo ho so, tai lieu lien quan den hoat dong cua doan va chuyen cho to churc KDCLGD de luru triur sau khi két thuc dot DGN; chuan bi ho so, tai lieu phuc vu viec giai trinh cac yeu cau khiéu nai hoac chat van co lien quan dén hoat dong cua doan.
b) Thu ky Thu ky co nhiem vu giup truong doan chuan bi ké hoach, trién khai cac hoat dong va chuan bi cac bao cao cua doan, tham gia cac hoat dong theo ké hoach chung cua doan va thuc hien cac nhiem vu do truong doan phan cong. Cu the: lap ké hoach, tap hop cac ho so, tai lieu cua doan de phuc vu cho viec viét cac bao cao cia doan, ghi chep noi dung cac buoi thao luan chung cua doan, tham gia viét cac bao cao cua doan va hoan thien bao cao chinh thurc, thuc hien cac cong viec khac theo su phan cong cua truong doan.
c) Cac thanh vien Cac thanh vien trong doan co trach nhiem tham gia cac hoat dong theo ké hoach chung cua doan va thuc hien nhiem vu do trurong doan phan cong, tham gia hoan thien bao cao chinh thirc cua doan.
3. Nguyen tac lam viec cia doan danh gia ngoai Doan DGN lam viec theo nguyen tac tap trung dan chi va dong thuan cac y kién trong doan.
Doi voi nhing noi dung khong dat dugc su nhat tri cua it nhat 2/3 s thanh vien trong doan DGN, truong doan co trach nhiem to churc hop doan de thao luan trurc tiep va dura ra quyet dinh cuoi cung.
II. CAC BUOC DANH GIA NGOAI Truoc khi co so giao duc dang ky DGN CTDT voi mot to chirc KDCLGD thi CTDT do phai duoc Bo GDDT cap nhat trong danh sach da hoan thanh bao cao TDG va dugc dang len Cong thong tin dien tur cua Bo GDDT. To churc KDCLGD chi DGN cac CTDT co ten trong danh sach da hoan thanh bao cao, duoc cong khai tren Cong thong tin dien tur cua Bo GDDT.
1. Buroc 1: Chuan bj
a) Cong tac chuan bi DGN CTDT chinh thurc durgc tién hanh sau khi co so giao duc va to churc KDCLGD da thuc hien viec tham dinh bao cao TDG CTDT va thoa thuan ky hop dong DGN duoc quy dinh tai

Dieu 15 cua Thong tur so 38/2013/TT-BGDDT, co so giao duc cing da guri cac file bao cao TDG (da duoc to churc KDCLGD tham dinh) cung van ban thong bao viec da hop dong DGN ve Cuc Quan ly chat luong.

b) Truroc khi thanh lap doan DGN, to churc KDCLGD thong bao danh sach dur kien doan DGN cho co so giao duc. Trong thoi han 1O ngay lam viec ke tu khi nhan dugc thong bao ve danh sach du kién doan DGN cua to churc KDCLGD, co so giao duc dugc quyen de nghi voi to churc KDCLGD dé thay doi mot hay nhieu thanh vien cia doan neu co minh churng thanh vien nay da turng co xung dot ve loi ich voi co so giao duc, nhung khong duroc goi y hay de xuat cac ca nhan khac tham gia doan DGN. Sau thoi han tren, néu co so giao duc khong co y kien thi coi nhu da dong y voi danh sach du kién cua to churc KDCLGD.
c) To churc KDCLGD thanh lap doan DGN, sau do guri ho so TDG CTDT va cac tai lieu lien quan cho doan DGN bao gom: (i) Bao cao TDG CTDT (bao gom ca phu luc voi danh muc cac minh churng kem theo); (i) Quyét dinh thanh lap doan DGN (kem theo ly lich trich ngang cua cac thanh vien doan danh gia);
(i) Cac van ban lien quan: Quy dinh ve quy trinh va chu ky kiem dinh chat luong CTDT; Quy dinh ve tieu chuan danh gia chat luong CTDT; Huong dan TDG va DGNCTDT.
Luu j: Trong truong hop can DGN doi voi CTDT thuoc Bo Quoc phong, Bo Cong an thi thanh lap doan DGN theo de nghi cia Bo Quoc phong, Bo Cong an.
d) To churc KDCLGD lam viec voi truong doan, thu ky doan DGN (co the co hoac khong co mat cac thanh vien khac) de trao doi, thong nhat du kién ké hoach cong tac cua doan va phan cong nhiem vu cu the cho turng thanh vien.
chuong trinh khao sat so bo va chuong trinh khao sat chinh thirc (tham khao Phu luc 10), thao luan voi cac thanh vien va phan cong nhiem vu cho cac thanh vien doan DGN.
e) Cac thanh vien doan DGN thuc hien nghien ciru truroc ho so TDG theo trinh tu:
- Doc va ra soat toan bo cau triuc cua ban bao cao TDG va nghien curu cac tai lieu lien quan;
- Nghien curu ky noi dung bao cao lien quan toi cac tieu chuan, tieu chi dugc phan cong;
- Viét nhan xet bao cao TDG CTDT (tham khao Phu luc 11) guri cho trurong doan va thur ky.
2. Buroc 2: Nghien ctru ho so tur danh gia Sau khi co du cac ban nhan xét bao cao TDG cua tat ca thanh vien, truong doan trieu tap doan DGN lam viec tap trung tu 1 den 2 ngay. Trong qua trinh lam viec tap trung, doan DGN thurc hien cac cong viec sau:
a) Nghien curu, trao doi ve cac ban nhan xét bao cao TDG cua cac thanh vien trong doan.

b) Thao luan dé thong nhat cac noi dung:
yeu cau trong van ban Huong dan TDG va DGN CTDT;
- Nhan xét bao cao TDG CTDT theo cac noi dung sau: (i) Viec mo ta cac hoat dong cua CTDT doi chiéu voi yeu cau cua tieu chi; (ii) Viec phan tich, so sanh cac diem manh, diem ton tai va nguyen nhan; (iii) Viec xac dinh nhung van de can cai tién chat luong va cac bien phap thurc hien cua co so dao tao; (iv) Viec sur dung thong tin va minh chung trong bao cao TDG; tinh day di, thong nhat cua cac thong tin va minh chung ve muc do dat duoc cua cac tieu chi; (v) Van phong, chinh ta, cach lap luan va ly giai trong bao cao TDG; (vi) Danh gia chung ve bao cao TDG;
- Cac y kiéen ve nhing tieu chi chua dugc danh gia hoac chua duoc phan tich va danh gia day du dan dén thiéu co so de khang dinh murc do dat cua tieu chi do;
- Danh sach nhung tieu chi can kiem tra, tham dinh lai hoac bo sung thong tin va minh chung;
- Danh muc nhung tu lieu, tai lieu can durgc kiem tra hoac nhung tur lieu, tai lieu can dugc bo sung;
- Du kién so luong va thanh phan doi turong de nghi durgc phong van trong dot khao sat chinh thurc tai co so giao duc (can bo lanh dao, quan ly co so giao duc va CTDT; giang vien; nghien ctru vien; nhan vien; nguoi hoc; nguoi hoc da tot nghiep va nha sir dung lao dong, ... lien quan den CTDT). Cac doi tuong phong van can bao dam du so luong, du co cau ve do tuoi va mang tinh dai dien. Doi turong phong van la giang vien, nguoi hoc, nguoi hoc da tot nghiep va nha sir dung lao dong can bao dam so luong tir 15 den 25 nguoi cho moi doi tuong; voi doi turong giang vien co the so luong phong van it hon nhung can bao dam du co cau ve do tuoi, tham nien cong tac, dai dien cac bo mon khac nhau (khong kiem nhiem churc vu lanh dao, quan ly cua don vi thurc hien CTDT dé khong trung voi doi turong phong van la can bo lanh dao, quan ly); voi doi tuong la nguoi hoc, phai duroc phan bo hop ly theo ty le sinh vien cua tirng nam hoc, dong thoi bao dam ty le hop ly giura can bo lop voi cac sinh vien khac; voi doi turong nguoi hoc da tot nghiep, can bao dam phan bo hop ly  cac nam khac nhau (khong lay nguoi hoc da tot nghiep la nguoi cua nha trurong); voi doi tuong la nha sit dung lao dong, phai bao dam co su phan bo hop ly gitra cac linh vurc chuyen mon lien quan va la lanh dao cua don vi trurc tiep sur dung sinh vien tot phong van mat giap mat voi phong van trurc tuyen.
- Du kién doi turong va noi dung phong van;
- Du kién nhung co so vat chat, trang thiét bi, cac hoat dong thurc hien CTDT can dugc quan sat;
- Du kién nhung tinh huong co thé phat sinh (néu co).

c) Thu ky tong hop cac noi dung tren thanh Du thao Bao cao két qua nghien curu Ho so TDG CTDT (tham khao Phu luc 12).
d) Truong doan DGN guri Du thao Bao cao két qua nghien curu Ho so TDG, cho cac thanh vien trong doan. Sau khi durgc it nhat 2/3 so thanh vien cua doan DGN nhat tri thong qua, trurong doan guri Bao cao ket qua nghien curu Ho so TDG cho to churc KDCLGD; to chuc KDCLGD guri cong van thong bao ve ké hoach lam viec cua doan den co so giao duc co CTDT duoc danh gia.
d) Sau khi da co y kién thong nhat voi co so giao duc, to churc KDCLGD guri cho co so giao duc Bao cao két qua nghien curu Ho so TDG de co so giao duc nghien curu truoc khi doan DGN den khao sat so bo.
3. Buroc 3: Khao sat so bo tai co' so giao duc Thong thuong, trong khoang thoi gian 15 ngay lam viec sau dot nghien curu Ho so TDG, trurong doan, thu ky (co the co hoac khong co mat cac thanh vien khac) den khao sat so bo tai co so giao duc. Cac noi dung lam viec bao gom:
a) Doan DGN thong bao va trao doi voi co so giao duc ve: (i) Két qua nghien curu Ho so TDG CTDT; (ii) Trao doi va thong nhat ké hoach khao sat chinh thurc cua doan gom: Thoi gian khao sat chinh thuc, nhung van de co so giao duc can chuan bi cho dot khao sat chinh thurc (tai lieu, ho so minh chung;
cac doi turong can moi de phong van; cac dia diem se tham quan, khao sat; cac hoat dong se quan sat; cac yeu cau chuan bi ve co so vat chat, trang thiét bi, hau can cho doan DGN);
b) Két thuc dot lam viec, hai ben ky Bien ban ghi nho sau khao sat so bo (tham khao Phu luc 13).
c) Trurong doan DGN guri Bien ban ghi nho sau khao sat so bo cho to churc KDCLGD.
d) Truoc khi tién hanh khao sat chinh churc it nhat 7 ngay lam viec, To churc KDCLGD guri cac file (word va pdf) Quyét dinh thanh lap doan DGN, Bien ban ghi nho sau khao sat so bo, Ke hoach khao sat chinh thurc ve Cuc Quan ly chat luong theo dia chi e-mail: phongkdclgd@moet.gov.vn.
4. Buroc 4: Khao sat chinh thirc tai co so giao duc
a) Thoi gian khao sat: Doan DGN dén khao sat tai co so giao duc trong khoang thoi gian tu 2 den 4 ngay.
b) Cac hoat dong chinh cua doan DGN trong khao sat chinh thurc bao gom: (i) Truong doan hop toan doan DGN dé quan triet nhiem vu cua tung thanh vien, cach thurc va ké hoach lam viec; (i) Doan hop voi lanh dao co so giao duc, lanh dao don vi co CTDT dugc danh gia va Hoi dong TDG CTDT;
(ii) Doan nghien curu cac ho so minh chung, tai lieu do co so giao duc cung cap;
(iv) Doan tham quan, phong van va thao luan tai cac phong, ban; tham quan, khao sat thu vien, phong hoc, phong thi nghiem, phong thurc hanh, ky tuc xa, cau lac bo sinh vien, .; quan sat cac hoat dong chinh khoa va ngoai khoa; phong

van can bo quan ly, giang vien, nghien curu vien, nhan vien, nguoi hoc, nguoi hoc da tot nghiep, nha siur dung lao dong; (v) Doan viet Bao cdo ket qud khao sat chinh thitc ve CTDT duoc danh gia (tham khao Phu luc 15).
c) Cuoi moi ngay lam viec, doan DGN hop so keét cong viec trong ngay va dieu chinh nhtrng diem can thiét trong chuong trinh lam viec cua ngay tiep theo.
Cac noi dung chuyen mon chinh can luu y trong hop doan DGN bao gom: (i) Thao luan ve nhung phat hien moi, nhung diem can luru y trong cac thong tin, dir lieu cia qua trinh khao sat; (ii) Thao luan ve nhung noi dung cua moi tieu chi:
diém manh va cac minh churng khang dinh dieu do; nhung diém ton tai va de xuat huong khac phuc; nhung diém chua ro; két qua dat duoc cua moi tieu chi;
(ii) Lap bang thong ke két qua danh gia cac tieu chi; (iv) Thong nhat ve nhung diem manh va diem ton tai cua moi tieu chi, khuyen nghi cua doan doi voi co so giao duc.
d) Cuoi dot khao sat, cac thanh vien cua doan DGN hoan thien Ban tong hgp két qua nghien curu sau cac tieu chi ma minh durgc phan cong (tham khao Phu luc 14) va nop cho thu ky. Ban tong hop ket qua hop két qua nghien curu sau cac tieu chi phai duroc thong qua doan DGN de hoan thien.
d) Thu ky tap hop cac Ban tong hop ket qua nghien curu sau cac tieu chi cua cac thanh vien va viet Du thao Bao cao két qua khao sat chinh thrc (tham khao Phu luc 15).
e) Doan DGN thao luan ve Dur thao Bao cao ket qud khao sat chinh thuic. Can dac biet chu y thao luan de thong nhat nhan dinh ve cac diem manh va diem ton tai chu yeu cua moi tieu chuan, tieu chi vé murc dat yeu cau cua tieu chi ma co sur khac biet trong cach danh gia giura co so giao duc voi cac thanh vien cua doan DGN. Bao cao phai durgc it nhat 2/3 so thanh vien cua doan DGN nhat tri thong qua.
g) Truroc khi ket thuc dot khao sat, doan DGN lam viec voi lanh dao co so giao duc, lanh dao don vi co CTDT dugc danh gia va Hoi dong TDG CTDT de thong bao nhiung cong viec da thuc hien va cac phat hien trong qua trinh khao sat, dong thoi hai ben ky Bien ban hoan thanh dot khao sat chinh thurc (tham khao Phu luc 16). Sau khi ket thuc danh gia tai co so giao duc, trurong doan guri Bao cao ket qua khao sat chinh thurc va Bien ban hoan thanh dot khao sat chinh thurc cho to churc KDCLGD.
5. Buroc 5: Viét bao cao danh gia ngoai
a) Bao cao DGN CTDT tham khao Phu luc 17 cua Huong dan nay;
b) Trach nhiem viét bao cao DGN: Tung thanh vien cua doan viét bao cao theo nhing tieu chi duroc phan cong va guri cho truong doan va thu ky de tong hop thanh Bao cao DGN CTDT cua doan; doi voi moi tieu chi, bao cao phai danh gia va co y kien de xuat ve diem manh, diem ton tai, ke hoach cai tien chat luong va bien phap thuc hien, nhirng noi dung chura ro va ket qua danh gia tieu chi;
c) Cac nguon tu lieu dé viét Bao cao DGN CTDT bao gom: (i) Bao cao TDG CTDT cua co so giao duc; (ii) Ban nhan xet bao cao TDG cua tung thanh

vien; (ii) Bao cao ve két qua nghien curu ho so TDG; (iv) Bao cao Tong hop két dung lam viec cua dot khao sat so bo; (vi) Bien ban hoan thanh dot khao sat chinh thurc; (vii) Bao cao ve ket qua khao sat chinh thurc tai co so giao duc;
DGN CTDT;
d) Sau khi hoan thanh ban Dur thao lan thtr nhat Bao cao DGN CTDT, thu ky guri den cac thanh vien trong doan de xin y kien gop y. Neu cac thanh vien trong doan khong thong nhat durgc y kién, thi sau khi sura chura phai tiép tuc guri Du thao lan thur hai de xin y kien lan 2. Neu Dur thao lan 2 van khong nhan duroc su nhat tri cua it nhat 2/3 so thanh vien trong doan, thi truong doan DGN phai hop doan de thao luan lan cuoi va truong doan co trach nhiem dua ra quyet dinh cuoi cung;
e) Sau khi doan DGN da thong nhat vé noi dung Dur thao bao cao DGN CTDT, truong doan guri ban Du thao bao cao nay cho to chirc KDCLGD de bao cao. Sau khi thong nhat y kien voi doan DGN, to chirc KDCLGD guri Du thao bao cao DGN CTDT cho co so giao duc de lay y kien phan hoi;
g) Trong thoi han 15 ngay lam viec, ke tur ngay nhan dugc Du thao bao cao DGN CTDT, co so giao duc co trach nhiem guri cong van cho doan DGN qua to churc KDCLGD, neu ro cac y kién nhat tri hoac khong nhat tri voi ban Du thao bao cao DGN CTDT. Truong hop khong nhat tri voi Du thao bao cao DGN CTDT phai neu ro ly do kem theo cac minh chung. Neu qua thoi han tren ma co so giao duc khong co y kien tra loi thi coi nhu dong y voi Dur thao bao cao DGN CTDT;
h) Trong thoi han 15 ngay lam viec, ké tur ngay nhan durgc y kién phan hoi thong qua to churc KDCLGD, doan DGN guri van ban thong bao cho co so giao duc nhirng y kién cua doan DGN da tiep thu hoac bao luru. Trurong hop doan DGN bao luru y kien phai neu ro ly do trong van ban;
i) Doan DGN hoan thien Bao cao DGN CTDT, lay chu ky cua tat ca cac thanh vien trong doan va guri Bao cao DGN CTDT cho to churc KDCLGD cung toan bo ho so lam viec cua doan, kem theo cac file dien tir lien quan;
k) Sau khi nhan Bao cao DGN CTDT nhiéu nhat la 07 ngay lam viec, to chirc KDCLGD guri file nay (word va pdf) vé Cuc Quan ly chat lurong theo dia chi e-mail: phongkdclgd@moet.gov.vn. Doi voi Bo Cong an va Bo Quoc phong, sau khi CTDT thuoc Bo minh quan ly dugc DGN, guri thong bao vé két qua DGN va qua trinh thuc hien quy trinh DGN ve Cuc Quan ly chat luong, Bo GDDT de theo doi chung.
III. CONG TAC HAU CAN, BAO CAO VA LUU TRU HO SO
1. Cong tac hau can
a) To churc KDCLGD va co so giao duc chu dong bo tri va bao dam cac dieu kien ve cho o, di lai, lam viec an toan va thuan loi cho doan DGN:

- Trong thoi gian khao sat tai co so giao duc, néu phai o lai thi bo tri noi o cua doan DGN nam ngoai khuon vien cua co so giao duc;
- Moi thanh vien doan DGN deu durgc cap thé dé deo khi dén lam viec tai co so giao duc. Thé phai co cac noi dung: tieu de “Doan DGN", ho va ten, trach nhiem trong doan (truong doan, thur ky, ..).
b) Co so giao duc co trach nhiem:
- Bo tri rieng mot phong lam viec co day du trang thiét bi (may tinh, may chiéu, may in, ...), van phong pham, nuoc uong trong suot thoi gian doan DGN khao sat chinh thurc tai co so giao duc. Ngoai cira phong co bien ghi “Phong lam viec cua Doan DGN, tur ngay... den ngay...";
- Bo tri day du dja diém dé phong van cac doi turong lien quan;
- Co so giao duc can thong bao rong rai toi can bo quan ly, giang vien, nghien curu vien, nhan vien va nguoi hoc cac thong tin vé viec DGN cua don vi.
Dong thoi, tao dieu kien thuan loi cho can bo quan ly, giang vien, nghien curu vien, nhan vien va nguoi hoc duroc tiep xuc va cung cap them thong tin cho doan DGN (néu can).
2. Bao cao va luru trir ho so'
a) He thong ho so can dugc sap xép khoa hoc, durgc so hoa dé de dang tra ciru cho cong tac chuyen mon hoac dap rng yeu cau kiem tra cia cac co quan co tham quyen;
trinh DGN theo huong dan da neu. Dong thoi, thurc hien viec cap nhat cac thong tin vao he thong quan ly cua Bo GDDT theo huong dan (trong thoi gian toi).
c) Ho so két qua lam viec cua doan DGN can luu trur bao gom:
- Quyét dinh thanh lap doan DGN;
- Ké hoach DGN;
- Ban nhan xét Bao cao TDG CTDT cua tung thanh vien;
- Ban tong hop két qua nghien curu sau cac tieu chi cua cac thanh vien;
- Bao cao két qua nghien ciru ho so TDG;
- Bien ban ghi nho sau khao sat so bo;
- Bao cao két qua khao sat chinh thurc;
- Bien ban hoan thanh dot khao sat chinh thirc;
- Cong van cua co so giao duc ve viec tiép thu hoac bao luu y kién cua du thao bao cao DGN (neu co);
- Bao cao DGN CTDT.
d) Thoi han bao quan, luu trir va sur dung ho so tai to churc KDCLGD theo quy dinh cua Luat luu tru va cac quy dinh hien hanh.

Tren day la huong dan chung ve TDG va DGN CTDT. Co so giao duc, to churc KDCLGD co thé bo sung cac bieu mau khac de phuc vu tot hon cho viec danh gia nhung phai bao dam dung quy trinh da dugc quy dinh tai Thong tu so 38/2013/TT-BGDDT. Ngoai ra, de tiet kiem thoi gian, nhan luc va chi phi cho ca hai ben, khuyen khich co so giao duc dang ky DGN cung luc mot so CTDT voito churcKDCLGD.
Cong van nay thay thé Cong van so 1075/KTKDCLGD-KDDH ngay 28/6/2016 cua Cuc Quan ly chat luong ve viec huong dan tu danh gia chuong trinh dao tao va Cong van so 1076/KTKDCLGD-KDDH ngay 28/6/2016 cia Cuc Quan ly chat luong ve viec huong dan danh gia ngoai chuong trinh dao tao.
Trong qua trinh trien khai thuc hien neu co nhung vuong mac hoac de xuat can lien he voi Phong KDCLGD, Cuc Quan ly chat luong, Bo GDDT theo dja chi: 35 Dai Co Viet, Hai Ba Trung, Ha Noi; email: phongkdclgd@moet.gov.vn de duroc giai quyét kip thoi./.
Noi nhan:
KT. CUC TRUONG
- Nhur tren;
PHO CEC TRUONG
- TT. Hoang Minh Son (dé b/c);
- Cuc trurong (de b/c);
CUC QUAN LYMR
- Cuc Nhatrurong (BoQuocphong);
-CucDaotao(BoCongan);
CHAT LUONG)
- Vu GDDH;
- Luu: VT, KDCLGD.
Le My Phong